package Logging;

import org.apache.log4j.FileAppender;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.SimpleLayout;

public class implementLogging {
	
	public static Logger logger = LogManager.getLogger(implementLogging.class);
	SimpleLayout layout = new SimpleLayout();
	public void logging() {
	try {
		System.out.println ("in logger method");
		FileAppender appender = new FileAppender(layout,"C:\\Users\\tkarmakar005\\eclipse-workspace\\Automation Framework 1\\src\\test\\resources\\logs\\logs.txt",false);
		logger.addAppender(appender);
	}
	catch(Exception e){
		System.out.println("Exception :"+e);
	}
	
}	

}
