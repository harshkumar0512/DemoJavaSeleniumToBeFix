package base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.spi.LoggerFactory;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.TestInfo;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.logging.LoggingPreferences;

import Reporting.reportingUtility;
import ch.qos.logback.classic.Logger;
import readDataExcel.readTestData;
import readDataExcel.readTestDataMulti;
import readDataExcel.readTranslationData;
import sharedLib.sharedLibClass;

//import io.github.bonigarcia.wdm.WebDriverManager;

public class baseClass {
	
	public static Properties prop;
	public static WebDriver driver;
	public static Reporting.reportingUtility rep;
	public static readDataExcel.readTestData excdata;
	public static readDataExcel.readTestDataMulti excdata1;
	public static readDataExcel.readTranslationData transldata;
	public static sharedLib.sharedLibClass shl;
	public String browserName = null;
	public String url = null;
	public String env = null;
	public String excelData;
	public String sheetlanguage = null;
	public String labelName = null;
	public String methodName = null;
	

	//This method will execute before the execution of all test cases
	@BeforeAll
	public void initialConfig() {
		loadConfig();
	}
	
	//Load Config file 
	public  void loadConfig(){
		prop = new Properties();
		try {
			FileInputStream fis = new FileInputStream (System.getProperty("user.dir")+"\\ConfigFiles\\config.properties");
			prop.load(fis);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	

	//Implement functions from shared library across projects
	public void implementSahredLibFuctions() {
		System.out.println ("Inside base report method");
		shl = new sharedLibClass();
	}
	
	//Read test data from excel using hash map by getting the method name
	/*public Object readExcelDatabeforeeach(String dataKey) {
		excdata = new readTestData();
		HashMap inputDataSet;
		inputDataSet= excdata.readInputExcel(methodName);
		return (inputDataSet.get(dataKey));
	}*/
	
	
	//Read test data from excel using hash map by getting the method name multi
		public Object readExcelDatabeforeeach(String dataKey,String iteration) {
			excdata1 = new readTestDataMulti();
			HashMap inputDataSet;
			inputDataSet= excdata1.readInputExcel(methodName,iteration);
			return (inputDataSet.get(dataKey));
		}
		
		
		public Object readExcelDatabeforeeach(String dataKey) {
			excdata1 = new readTestDataMulti();
			HashMap inputDataSet;
			inputDataSet= excdata1.readInputExcel(methodName,"Test Data 1");
			return (inputDataSet.get(dataKey));
		}
	
	//Read data from translation file excel using hash map based on language provided in properties file
	public Object readExcelTranslationData(String labelName) {
		transldata = new readTranslationData();
		sheetlanguage=prop.getProperty("language");
		HashMap inputDataSet;
		inputDataSet= transldata.readInputTransExcel(sheetlanguage,labelName);
		System.out.println(inputDataSet.get(labelName));
		return (inputDataSet.get(labelName));
		//return inputDataSet;
	}
	

	//Fetch method name of the test to be executed before each test execution
	@BeforeEach
	public void getMethodName(TestInfo testInfo) {
		methodName = testInfo.getTestMethod().orElseThrow().getName();
	}
	
	//initialize WebDriver
	//launch Browser
	@BeforeEach
	public void loadBrowser() throws InterruptedException {
		System.out.println("Inside load browser method");
		browserName = prop.getProperty("browser");
		env = prop.getProperty("environment");
		if (env.contains("Prod"))
		{
			url = prop.getProperty("produrl");
		}
		else if (env.contains("QA"))
		{
			url = prop.getProperty("qaurl");
		}
		if (browserName.contains("Chrome")) {
			System.out.println ("Chrome");
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\tkarmakar005\\eclipse-workspace\\Automation Framework 1\\src\\main\\resources\\Drivers\\chromedriver.exe");
			ChromeOptions c_options = new ChromeOptions();
			c_options.setUnhandledPromptBehaviour(UnexpectedAlertBehaviour.ACCEPT);
			driver = new ChromeDriver();
			//WebDriverManager.chromeDriver().setup();
		}
		else if (browserName.contains("FireFox")) {
			System.out.println ("Firefox");
			String geckoDriverPath =  "C:\\Users\\tkarmakar005\\eclipse-workspace\\Automation JUnit\\GEMAutomation\\src\\main\\resources\\Drivers\\geckodriver.exe";;
			System.setProperty("webdriver.gecko.driver", geckoDriverPath);
			new LoggingPreferences();
			FirefoxOptions f_options = new FirefoxOptions();
			f_options.setProfile(new FirefoxProfile());
			f_options.setUnhandledPromptBehaviour(UnexpectedAlertBehaviour.ACCEPT);
			driver = new FirefoxDriver();
		}
		else if (browserName.contains("Edge")) {
			System.out.println ("Edge");
			String ieDriverPath = "C:\\Users\\tkarmakar005\\eclipse-workspace\\Automation JUnit\\GEMAutomation\\src\\main\\resources\\Drivers\\msedgedriver.exe";
			InternetExplorerOptions options = new InternetExplorerOptions();
			options.setUnhandledPromptBehaviour(UnexpectedAlertBehaviour.ACCEPT);
			options.introduceFlakinessByIgnoringSecurityDomains();
			options.ignoreZoomSettings();
			// options.takeFullPageScreenshot();
			System.setProperty("webdriver.edge.driver",ieDriverPath);
			driver = new EdgeDriver();
		}
		else if (browserName.contains("chromeMobile")) {
			System.out.println ("chromeMobile");
			String chromeDriverPath1 =  "C:\\Users\\tkarmakar005\\eclipse-workspace\\Automation Framework 1\\src\\main\\resources\\Drivers\\chromedriver.exe";
			Map<String, String> mobileEmulation = new HashMap<>();
			mobileEmulation.put("deviceName", "iPhone X");
			ChromeOptions chromeOptions = new ChromeOptions();
			chromeOptions.setExperimentalOption("mobileEmulation", mobileEmulation);
			// System.setProperty("webdriver.chrome.driver", chromeDriverPath1);
			// WebDriver driver = new ChromeDriver(chromeOptions);
			System.setProperty("webdriver.chrome.driver", chromeDriverPath1);
			driver = new ChromeDriver();
		}
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.get(url);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(500));
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(500));
	}	
	
	//Close webDriver
	//@AfterTest
	public void endSession() {
		driver.quit();
	}
}

