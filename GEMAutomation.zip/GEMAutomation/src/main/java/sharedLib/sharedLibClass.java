package sharedLib;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;

import base.baseClass;
import jdk.internal.org.jline.utils.Log;



public class sharedLibClass extends baseClass{

	//final Logger LOG = 	(Logger) LoggerFactory.getLogger(getClass());
	
public void robotClickPaste()  {
	Robot rb;
	try {
		rb = new Robot();
	    rb.keyPress(KeyEvent.VK_CONTROL);
	    rb.keyPress(KeyEvent.VK_V);
	    rb.keyRelease(KeyEvent.VK_CONTROL);
	    rb.keyRelease(KeyEvent.VK_V);
	    robotClick();
	} catch (AWTException e) {
		e.printStackTrace();
		System.out.println("Element not present");
	}

}

public void robotClick() {
	Robot rb;
	try {
		rb = new Robot();
	    rb.keyPress(KeyEvent.VK_ENTER);
	    rb.keyRelease(KeyEvent.VK_ENTER);
	} catch (AWTException e) {
		e.printStackTrace();
		System.out.println("Element not present");

	}
}


public void customClick(Object WebElement) {
	try {
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();", WebElement);
	} catch (ElementNotInteractableException e) {
		robotClick();
	} catch (Exception g) {
		g.printStackTrace();
		System.out.println("Element not present");
	}
}

	
}
