package Reporting;

public class reportingUtility {
	public void reporting() {
		System.out.println("Inside reporting");
	}
}
