package readDataExcel;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class readTestDataMulti {
	public static XSSFSheet ExcelWSheet;
	public static XSSFWorkbook ExcelWBook;
	public static XSSFCell Cell;
	public static XSSFRow Row;
	
	public HashMap<String,String> readInputExcel(String testCase,String iteration) 
	{
		HashMap<String, String> mapDet; 
		mapDet=new HashMap<String, String>();
		
		try {
			System.out.println("Inside read data");
			File file = new File ("C:\\Users\\tkarmakar005\\eclipse-workspace\\Automation JUnit\\GEMAutomation\\src\\test\\resources\\testdata\\TestData.xlsx");
			FileInputStream excelFile = new FileInputStream(file);
			@SuppressWarnings("resource")
			XSSFWorkbook ExcelWBook = new XSSFWorkbook(excelFile);
			XSSFSheet ExcelWSheet = ExcelWBook.getSheet("TestCaseData");
			
			int firstRow = ExcelWSheet.getFirstRowNum();
			int lastRow = ExcelWSheet.getLastRowNum();
			
			int totalRows = ExcelWSheet.getLastRowNum()+ 1;
			int totalCols= ExcelWSheet.getRow(0).getLastCellNum();

			int i,j,ci,cj;
			
		  	 String key="";	
		  	 String value="";	
			
			System.out.println(firstRow);
			System.out.println(lastRow);
			System.out.println(totalRows);
			System.out.println(totalCols);
			
			if (iteration.equals(""))
				iteration = "Test Data 1";
			
				for (i=1;i<totalRows;i++) {
				System.out.println("Inside first hashmap loop");
				Row row = ExcelWSheet.getRow(i);
				Row row1 = ExcelWSheet.getRow(0);
				if (row.getCell(0).getStringCellValue().contains(testCase)&& 
						row.getCell(1).getStringCellValue().contains(iteration))
				{
					for (j=0;j<totalCols;j++) {
						key = row1.getCell(j).getStringCellValue();
						value = row.getCell(j).getStringCellValue();
						System.out.println("Key Value pair ::: "+key +" : " + value);	
						mapDet.put(key, value);
					}
				break;
				}
			}
				
		}
		catch (FileNotFoundException e){
			System.out.println("Could not read the Excel sheet");
			e.printStackTrace();
		}

		catch (IOException e){
			System.out.println("Could not read the Excel sheet");
			e.printStackTrace();
		}
		
		return (mapDet);
	}
}
