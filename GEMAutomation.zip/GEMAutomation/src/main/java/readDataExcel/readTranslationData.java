package readDataExcel;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class readTranslationData {
	
	public static XSSFSheet ExcelWSheet;
	public static XSSFWorkbook ExcelWBook;
	public static XSSFCell Cell;
	public static XSSFRow Row;
	
	@SuppressWarnings("unlikely-arg-type")
	public HashMap<String,String> readInputTransExcel(String sheetlanguage,String label) 
	{
		//String[][] tabArray=null;
		HashMap<String, String> mapDet; 
		mapDet=new HashMap<String, String>();
		
		try {
			System.out.println("Inside read data");
			File file = new File ("C:\\Users\\tkarmakar005\\eclipse-workspace\\Automation JUnit\\GEMAutomation\\src\\test\\resources\\testdata\\LabelTranslationFile.xlsx");
			FileInputStream excelFile = new FileInputStream(file);
			@SuppressWarnings("resource")
			XSSFWorkbook ExcelWBook = new XSSFWorkbook(excelFile);
			XSSFSheet ExcelWSheet = ExcelWBook.getSheet(sheetlanguage);
			
			int firstRow = ExcelWSheet.getFirstRowNum();
			int lastRow = ExcelWSheet.getLastRowNum();
			
			int totalRows = ExcelWSheet.getLastRowNum()+ 1;
			int totalCols= ExcelWSheet.getRow(0).getLastCellNum();

			int i,j,ci,cj;
			
			//tabArray=new String[totalRows][totalCols];
			
		  	 String key="";	
		  	 String value="";	
		  	 String labelname="";
		  	String labelValue="";
		  	
			System.out.println(firstRow);
			System.out.println(lastRow);
			System.out.println(totalRows);
			System.out.println(totalCols);
			System.out.println(label);

			/*Push the data into a hash map
			for (i=firstRow;i<totalRows;i++) {
				System.out.println("Inside first hashmap loop");
				Row row = ExcelWSheet.getRow(i);
				for (j=0;j<totalCols-1;j++) {
					System.out.println("Inside second hashmap loop");
					String labelname = row.getCell(j).getStringCellValue();
					String labelValue = row.getCell(j+1).getStringCellValue();
					key = labelname;
					value = labelValue;
					System.out.println("Key Value pair ::: "+key +" : " + value);	
			 		mapDet.put(key, value);
				}
			}*/
			for (i=1;i<totalRows;i++) {
				System.out.println("Inside first hashmap loop");
				Row row = ExcelWSheet.getRow(i);
				if (row.getCell(0).getStringCellValue().equals(label))
				{
					labelname = row.getCell(0).getStringCellValue();
					if (sheetlanguage.contains("English")) {
						labelValue = row.getCell(1).getStringCellValue();
					} else {
						labelValue = row.getCell(2).getStringCellValue();
					}
					key = labelname;
					value = labelValue;
					System.out.println("Key Value pair ::: "+key +" : " + value);
					mapDet.put(key, value);
					break;
				}
			}
			
		}
		catch (FileNotFoundException e){
			System.out.println("Could not read the Excel sheet");
			e.printStackTrace();
		}

		catch (IOException e){
			System.out.println("Could not read the Excel sheet");
			e.printStackTrace();
		}
		
		return (mapDet);
	}
}