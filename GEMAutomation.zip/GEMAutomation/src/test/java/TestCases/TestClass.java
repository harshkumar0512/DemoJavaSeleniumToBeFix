package TestCases;

import java.awt.AWTException;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.LoggerFactory;

import base.baseClass;
import ch.qos.logback.classic.Logger;
import pageObjects.ClaimStartingPage;
import pageObjects.CommonLibs;

import readDataExcel.readTranslationData;
import readDataExcel.readTestData;

@TestInstance(Lifecycle.PER_CLASS)
public class TestClass extends baseClass {
	

	CommonLibs gp = new CommonLibs();
	ClaimStartingPage csp = new ClaimStartingPage();
	
	final Logger LOG = 	(Logger) LoggerFactory.getLogger(getClass());

	@Test
	public void TC02() throws InterruptedException, AWTException
	{
		System.out.println("Inside test class");
		PageFactory.initElements(driver, gp);
		PageFactory.initElements(driver, csp);
		gp.createNewClaim();
		gp.selectClaimType(readExcelDatabeforeeach("claimtype"));
		csp.selectTravellingOrNotRadioButton(readExcelDatabeforeeach("travelling"));
		csp.selectCancelReason(readExcelDatabeforeeach("cancelreason"));
		csp.selectDeceasedPersonInsuranceCoverage(readExcelDatabeforeeach("deceasedinspolicy"));
		csp.selectClaimPresent(readExcelDatabeforeeach("claimpresent"));
		//gp.verifyDocumentList();
		gp.getDocumentList();
		gp.clickReadyButton();
		//gp.uploadDocs();
		//gp.continueButton();
		
		
		
		//System.out.println("Test Data : "+readExcelDatabeforeeach("firstname","Test Data 1"));
		//System.out.println("Test Data : "+readExcelDatabeforeeach("firstname","Test Data 2"));
		
	    LOG.info("This is an INFO level log message!");
	    LOG.error("This is an ERROR level log message!");
	}
}
