package TestCases;

public class TripInterruption {

}
