package TestCases;

public class Student {

}
