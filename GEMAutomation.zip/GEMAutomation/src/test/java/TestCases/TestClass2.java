package TestCases;



import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.slf4j.LoggerFactory;

import base.baseClass;
import ch.qos.logback.classic.Logger;
import io.qameta.allure.Description;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import io.qameta.allure.Story;
import junit.framework.Assert;


@TestInstance(Lifecycle.PER_CLASS)
@Epic("Check functionality")
@Feature("Check features")
public class TestClass2 extends baseClass{
	
	final Logger LOG = 	(Logger) LoggerFactory.getLogger(getClass());
	
	@SuppressWarnings("deprecation")
	//@Test
	@Story("Story1")
	@Description("Verify a pass scenario")
	public void test3() {
		//logger.info("test");
		//logger.warn("this class will pass");
		Assert.assertTrue("Pass scenario", true);
		LOG.info("This is a passed test");
	}
	
	//@Test
	@Story("Story2")
	@Description("Verify a fail scenario")
	public void test4() {
		//logger.info("test2");
		//logger.warn("this class will fail");
		Assert.assertTrue("Pass scenario", false);
		LOG.info("This is a passed test");
	}


}
