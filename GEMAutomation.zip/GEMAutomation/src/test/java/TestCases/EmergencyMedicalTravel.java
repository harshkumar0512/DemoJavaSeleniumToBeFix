package TestCases;

public class EmergencyMedicalTravel {

}
