package pageObjects;

public class EventDescriptionEntryPage {

}
