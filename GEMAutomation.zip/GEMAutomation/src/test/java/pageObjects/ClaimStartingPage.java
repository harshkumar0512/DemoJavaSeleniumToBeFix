package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import base.baseClass;
import sharedLib.sharedLibClass;

public class ClaimStartingPage extends baseClass {
	
	
	sharedLibClass slb = new sharedLibClass();
	
	@FindBy(xpath="//input[@id='9b75774cb59df5458e1a7b0ead95d268_0']")
	private WebElement travellingIndividualRadioButtonYes;
	
	@FindBy(xpath="//input[@id='9b75774cb59df5458e1a7b0ead95d268_1']")
	private WebElement travellingIndividualRadioButtonNo;
	
	@FindBy(xpath="//span[@id='94e6dd8c7ebf5bec0e3cb8761448a261_value_span']")
	private WebElement selectcancelReasonDropdown;
	
	@FindBy(xpath="//li[@id='94e6dd8c7ebf5bec0e3cb8761448a261_list_1']")
	private WebElement selectCancelReason1;
	
	@FindBy(xpath="//li[@id='94e6dd8c7ebf5bec0e3cb8761448a261_list_2']")
	private WebElement selectCancelReason2;
	
	@FindBy(xpath="//li[@id='94e6dd8c7ebf5bec0e3cb8761448a261_list_3']")
	private WebElement selectCancelReason3;
	
	@FindBy(xpath="//input[@id='416ffda4feb61c8b210184c2f872f74b_0']")
	private WebElement deceasedinspolicyButtonYes;
	
	@FindBy(xpath="//input[@id='416ffda4feb61c8b210184c2f872f74b_1']")
	private WebElement deceasedinspolicyButtonNo;
	
	@FindBy(xpath="//input[@id='912ef968a0eaaa226735d361b57cc564_0']")
	private WebElement claimPresentButtonYes;
	
	@FindBy(xpath="//input[@id='912ef968a0eaaa226735d361b57cc564_1']")
	private WebElement claimPresentButtonNo;
	
		
	public void selectTravellingOrNotRadioButton(Object travellingOption) {
		if (travellingOption.equals("Yes")) {
			slb.customClick(travellingIndividualRadioButtonYes);
		} else {
			slb.customClick(travellingIndividualRadioButtonNo);
		}	
	}
	
	public void selectCancelReason(Object cancelReason) {
		selectcancelReasonDropdown.click();
		if (cancelReason.equals("Death")) {
		selectCancelReason1.click();
		} else if (cancelReason.equals("Medical")) {
			selectCancelReason2.click();
		} else if (cancelReason.equals("Other")) {
			selectCancelReason3.click();
		}
	}
	
	public void selectDeceasedPersonInsuranceCoverage(Object deceasedinspolicy) {
		if (deceasedinspolicy.equals("Yes")) {
			slb.customClick(deceasedinspolicyButtonYes);
		} else {
			slb.customClick(deceasedinspolicyButtonNo);
		}
	}
	
	public void selectClaimPresent(Object claimpresent) {
		if (claimpresent.equals("Yes")) {
			slb.customClick(claimPresentButtonYes);
		} else {
			slb.customClick(claimPresentButtonNo);
		}
	}
}




