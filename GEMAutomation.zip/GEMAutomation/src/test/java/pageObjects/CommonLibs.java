package pageObjects;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import base.baseClass;

public class CommonLibs extends baseClass {
	
	//private WebDriver driver;
	
	
	@FindBy(xpath="//span[@id='78d34405f7c4bec3bdba6f2eba625731-a11y-text']/following-sibling::div/child::p")
	private WebElement newClaimButton;
	
	@FindBy(xpath="//span[@id='0c8b31d7b6a7b265079667887e9cf1da-a11y-text']/following-sibling::div/child::p")
	private WebElement generateDocChecklistBtn;
	
	@FindBy(xpath="//button[@class='Button---btn Button---default_direction Button---primary appian-context-first-in-list appian-context-last-in-list Button---inSideBySide Button---icon_start']/span")
	private WebElement Readybtn;
	
	/*public CommonLibs(WebDriver driver) { 
		this.driver = driver;   
	    PageFactory.initElements( driver, this); 
	   }*/
	
	public void createNewClaim() {
		newClaimButton.click();
	}
	
	public void selectClaimType(Object claimType) {
		//WebElement selectClaimClick = 
			//	driver.findElement(By.xpath("//span[contains(text(),'"+claimType+"')]"));
		WebElement selectClaimClick = 
				driver.findElement(By.xpath("//span[@id='6d5d55c3491acad36fafa9adc33979f7']/parent::div/parent::div"));
		selectClaimClick.click();
	}
	
	public void getDocumentList() {
		generateDocChecklistBtn.click();
	}
	
	public void clickReadyButton() {
	Readybtn.click();
	}
	
	public void verifyDocumentList() {
		WebElement doclist = 
				driver.findElement(By.xpath("//div[@class='ColumnArrayLayout---column_layout ColumnArrayLayout---standard_spacing appian-context-last-in-list']"));
		String ss = doclist.getText();
		System.out.println(ss);
	}
	
	
	/*public void uploadDocs() throws InterruptedException, AWTException {
		
		StringSelection str = new StringSelection("C:\\Users\\tkarmakar005\\eclipse-workspace\\Automation JUnit\\GEMAutomation\\src\\test\\resources\\testdata\\Test.pdf");
		
		//First document upload
		WebElement uploadButton1 =
		driver.findElement(By.xpath("//span[contains(text(),'Travel Booking Invoice')]/following-sibling::div/child::input/following-sibling::div"));		
		uploadButton1.click();
		Thread.sleep(2000);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, null);
		shl.robotClickPaste();
    
	    //Second document upload
	    WebElement uploadButton2 =
	    driver.findElement(By.xpath("//span[contains(text(),'Original Itinerary')]/following-sibling::div/child::input/following-sibling::div"));		
	    uploadButton2.click();
	    Thread.sleep(2000);
	    Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, null);
	    shl.robotClickPaste();
	    	    
	   //Third document upload 	    
	    WebElement uploadButton3 =
	    driver.findElement(By.xpath("//span[contains(text(),'Proof of Payment')]/following-sibling::div/child::input/following-sibling::div"));		
	    uploadButton3.click();
	    Thread.sleep(2000);
	    Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, null);
	    shl.robotClickPaste();
	    
		//Fourth document upload 	    
	    WebElement uploadButton4 =
	    driver.findElement(By.xpath("//span[contains(text(),'Proof of Cancellation')]/following-sibling::div/child::input/following-sibling::div"));		
	    uploadButton4.click();
	    Thread.sleep(2000);
	    Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, null);
	    shl.robotClickPaste();
    
		//Fifth document upload 	    
	    WebElement uploadButton5 =
	    driver.findElement(By.xpath("//span[contains(text(),'Proof of Event - Death Certificate')]/following-sibling::div/child::input/following-sibling::div"));		
	    uploadButton5.click();
	    Thread.sleep(2000);
	    Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, null);
	    shl.robotClickPaste();
	}
	
	public void continueButton() {
		WebElement continueButton = 
				driver.findElement(By.xpath("//button[@class='Button---btn Button---default_direction Button---primary appian-context-first-in-list appian-context-last-in-list Button---inSideBySide Button---icon_start']"));
		continueButton.click();
	}*/
}
