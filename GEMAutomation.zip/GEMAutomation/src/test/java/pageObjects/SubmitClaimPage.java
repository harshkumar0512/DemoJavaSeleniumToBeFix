package pageObjects;

public class SubmitClaimPage {

}
