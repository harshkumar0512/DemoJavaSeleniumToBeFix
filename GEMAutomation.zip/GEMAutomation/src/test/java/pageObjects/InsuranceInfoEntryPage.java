package pageObjects;

public class InsuranceInfoEntryPage {

}
